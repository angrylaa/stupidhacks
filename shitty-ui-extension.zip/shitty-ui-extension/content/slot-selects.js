(function () {
  "use strict";

  const U = window.__SHITTY_UI__;
  if (!U) return;

  function openSlotGate(selectEl) {
    U.ensureHost();

    const opts = Array.from(selectEl.options).map((o) => ({
      value: o.value,
      label: (o.textContent || "").trim() || o.value,
    }));
    if (!opts.length) return;

    const panel = document.createElement("div");
    panel.className = "panel";
    Object.assign(panel.style, { maxWidth: "min(94vw, 440px)" });

    const h2 = document.createElement("h2");
    h2.textContent = "Committee randomizer";
    const sub = document.createElement("p");
    sub.className = "sub";
    sub.textContent =
      "Dropdowns are too efficient. Spin the ceremonial reels until fate aligns (approximately) with your intent.";

    const reels = document.createElement("div");
    Object.assign(reels.style, {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: "12px",
      marginBottom: "16px",
    });

    const state = [0, 0, 0];
    const stripHeight = 44;
    const visibleRows = 3;

    function makeReel(idx) {
      const wrap = document.createElement("div");
      Object.assign(wrap.style, {
        background: "rgba(0,0,0,0.5)",
        borderRadius: "12px",
        border: "1px solid rgba(255,255,255,0.12)",
        height: `${stripHeight * visibleRows}px`,
        overflow: "hidden",
        position: "relative",
      });
      const inner = document.createElement("div");
      Object.assign(inner.style, {
        transition: "transform 0.1s linear",
        willChange: "transform",
      });

      const labels = opts.map((o) => o.label);
      const extended = labels.concat(labels, labels);

      extended.forEach((label) => {
        const row = document.createElement("div");
        row.textContent = label.length > 18 ? label.slice(0, 16) + "…" : label;
        Object.assign(row.style, {
          height: `${stripHeight}px`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "0.78rem",
          padding: "0 6px",
          textAlign: "center",
          color: "#ddd",
        });
        inner.appendChild(row);
      });

      wrap.appendChild(inner);
      return { wrap, inner, labelsLen: labels.length };
    }

    const reelEls = [makeReel(0), makeReel(1), makeReel(2)];

    reelEls.forEach((r) => reels.appendChild(r.wrap));

    const status = document.createElement("div");
    Object.assign(status.style, {
      textAlign: "center",
      fontSize: "0.85rem",
      opacity: "0.85",
      marginBottom: "12px",
      minHeight: "1.4em",
    });
    status.textContent = "Spins left: 3";

    const row = document.createElement("div");
    row.className = "row";
    Object.assign(row.style, { justifyContent: "center" });

    const spinBtn = document.createElement("button");
    spinBtn.type = "button";
    spinBtn.className = "btn btn-primary";
    spinBtn.textContent = "Spin the reels";

    const useBtn = document.createElement("button");
    useBtn.type = "button";
    useBtn.className = "btn btn-ghost";
    useBtn.textContent = "Accept this timeline";
    useBtn.style.opacity = "0.45";
    useBtn.disabled = true;

    row.appendChild(spinBtn);
    row.appendChild(useBtn);

    panel.appendChild(h2);
    panel.appendChild(sub);
    panel.appendChild(reels);
    panel.appendChild(status);
    panel.appendChild(row);

    const { close } = U.showBackdrop(panel);

    let spins = 3;
    let settled = false;

    function offsetForIndex(reelIdx, logicalIndex) {
      const len = reelEls[reelIdx].labelsLen;
      const base = len;
      return -(base + logicalIndex) * stripHeight + stripHeight;
    }

    function applyTransforms() {
      reelEls.forEach((r, i) => {
        const y = offsetForIndex(i, state[i]);
        r.inner.style.transform = `translateY(${y}px)`;
      });
    }

    applyTransforms();

    function randomIndices() {
      const len = opts.length;
      return [
        Math.floor(Math.random() * len),
        Math.floor(Math.random() * len),
        Math.floor(Math.random() * len),
      ];
    }

    spinBtn.addEventListener("click", () => {
      if (settled || spins <= 0) return;
      spins -= 1;
      status.textContent = spins > 0 ? `Spins left: ${spins}` : "No spins left. You must accept reality.";

      const next = randomIndices();
      reelEls.forEach((r, i) => {
        r.inner.style.transition = "none";
        r.inner.style.transform = `translateY(${offsetForIndex(i, state[i])}px)`;
        void r.inner.offsetHeight;
        r.inner.style.transition = "transform 1.1s cubic-bezier(0.12, 0.85, 0.22, 1)";
        state[i] = next[i];
        r.inner.style.transform = `translateY(${offsetForIndex(i, state[i])}px)`;
      });

      if (spins === 0) {
        settled = true;
        spinBtn.disabled = true;
        spinBtn.style.opacity = "0.4";
        useBtn.disabled = false;
        useBtn.style.opacity = "1";
      }
    });

    useBtn.addEventListener("click", () => {
      if (!settled) return;
      const pick = state[Math.floor(Math.random() * 3)];
      selectEl.selectedIndex = pick;
      selectEl.dispatchEvent(new Event("input", { bubbles: true }));
      selectEl.dispatchEvent(new Event("change", { bubbles: true }));
      close();
    });
  }

  document.addEventListener(
    "pointerdown",
    function (e) {
      const s = U.settings;
      if (!s || !s.slotSelects) return;

      if (e.composedPath().some((n) => n instanceof Element && n.id === "shitty-ui-extension-root")) return;

      const t = e.target;
      if (t && t.closest && t.closest("[data-shitty-ui]")) return;

      let el = t;
      for (let i = 0; i < 6 && el; i++) {
        if (el.tagName === "SELECT" && !el.disabled) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          openSlotGate(el);
          return;
        }
        el = el.parentElement;
      }
    },
    true
  );
})();
