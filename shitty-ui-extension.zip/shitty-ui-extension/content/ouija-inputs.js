(function () {
  "use strict";

  const U = window.__SHITTY_UI__;
  if (!U) return;

  const skip = new WeakMap();

  function isTextField(el) {
    if (!el || el.tagName !== "INPUT" && el.tagName !== "TEXTAREA") return false;
    if (el.closest("[data-shitty-ui]")) return false;
    if (el.readOnly || el.disabled) return false;
    if (el.tagName === "INPUT") {
      const t = (el.type || "text").toLowerCase();
      const ok = ["text", "search", "email", "url", "tel", "password", "number"];
      return ok.includes(t);
    }
    return true;
  }

  function lettersLayout() {
    const rows = [
      "ABCDEFGHI",
      "JKLMNOPQR",
      "STUVWXYZ",
    ];
    const extra = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "@", "-", "_", "space", "⌫"];
    return { rows, extra };
  }

  function openOuija(targetEl) {
    U.ensureHost();

    let buffer = targetEl.value || "";

    const panel = document.createElement("div");
    panel.className = "panel";
    Object.assign(panel.style, { maxWidth: "min(96vw, 520px)" });

    const h2 = document.createElement("h2");
    h2.textContent = "The spirits demand letters";
    const sub = document.createElement("p");
    sub.className = "sub";
    sub.textContent =
      "Physical keyboards are forbidden. Channel each character through the board. The planchette is imaginary but the suffering is real.";

    const preview = document.createElement("div");
    Object.assign(preview.style, {
      minHeight: "48px",
      padding: "12px 14px",
      background: "rgba(0,0,0,0.45)",
      borderRadius: "10px",
      fontFamily: "Georgia, serif",
      fontSize: "1.1rem",
      letterSpacing: "0.06em",
      marginBottom: "14px",
      wordBreak: "break-all",
      border: "1px solid rgba(167,139,250,0.35)",
    });

    const isPassword = targetEl.tagName === "INPUT" && (targetEl.type || "").toLowerCase() === "password";

    function renderPreview() {
      if (!buffer) {
        preview.textContent = "…";
        return;
      }
      preview.textContent = isPassword ? "•".repeat(buffer.length) : buffer;
    }
    renderPreview();

    const board = document.createElement("div");
    Object.assign(board.style, {
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      marginBottom: "14px",
    });

    function makeKey(char, label) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = label || char;
      Object.assign(b.style, {
        minWidth: "32px",
        height: "36px",
        padding: "0 8px",
        borderRadius: "8px",
        border: "1px solid rgba(255,255,255,0.15)",
        background: "linear-gradient(180deg, #2d2d44, #1f1f30)",
        color: "#e8e8e8",
        cursor: "pointer",
        fontSize: "0.8rem",
        fontWeight: "600",
      });
      b.addEventListener("mouseenter", () => {
        b.style.transform = "translateY(-1px)";
        b.style.borderColor = "rgba(167,139,250,0.5)";
      });
      b.addEventListener("mouseleave", () => {
        b.style.transform = "";
        b.style.borderColor = "rgba(255,255,255,0.15)";
      });
      b.addEventListener("click", () => {
        if (char === "BACK") {
          buffer = buffer.slice(0, -1);
        } else if (char === "SPACE") {
          buffer += " ";
        } else {
          buffer += char;
        }
        renderPreview();
      });
      return b;
    }

    const { rows, extra } = lettersLayout();
    rows.forEach((row) => {
      const r = document.createElement("div");
      Object.assign(r.style, { display: "flex", flexWrap: "wrap", gap: "6px", justifyContent: "center" });
      for (const ch of row) r.appendChild(makeKey(ch, ch));
      board.appendChild(r);
    });

    const ex = document.createElement("div");
    Object.assign(ex.style, { display: "flex", flexWrap: "wrap", gap: "6px", justifyContent: "center" });
    extra.forEach((item) => {
      if (item === "space") ex.appendChild(makeKey("SPACE", "space"));
      else if (item === "⌫") ex.appendChild(makeKey("BACK", "⌫"));
      else ex.appendChild(makeKey(item, item));
    });
    board.appendChild(ex);

    const row = document.createElement("div");
    row.className = "row";

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "btn btn-ghost";
    cancel.textContent = "Cancel séance";

    const done = document.createElement("button");
    done.type = "button";
    done.className = "btn btn-primary";
    done.textContent = "Possess field";

    row.appendChild(cancel);
    row.appendChild(done);

    panel.appendChild(h2);
    panel.appendChild(sub);
    panel.appendChild(preview);
    panel.appendChild(board);
    panel.appendChild(row);

    const { close } = U.showBackdrop(panel);

    cancel.addEventListener("click", () => close());

    done.addEventListener("click", () => {
      const desc = Object.getOwnPropertyDescriptor(
        targetEl.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
        "value"
      );
      if (desc && desc.set) desc.set.call(targetEl, buffer);
      else targetEl.value = buffer;
      targetEl.dispatchEvent(new Event("input", { bubbles: true }));
      targetEl.dispatchEvent(new Event("change", { bubbles: true }));
      close();
      skip.set(targetEl, true);
      targetEl.focus();
      requestAnimationFrame(() => {
        skip.delete(targetEl);
      });
    });
  }

  document.addEventListener(
    "focusin",
    function (e) {
      const s = U.settings;
      if (!s || !s.ouijaInputs) return;

      if (e.composedPath().some((n) => n instanceof Element && n.id === "shitty-ui-extension-root")) return;

      const t = e.target;
      if (!isTextField(t)) return;
      if (skip.get(t)) return;

      t.blur();
      openOuija(t);
    },
    true
  );
})();
