(function () {
  "use strict";

  window.__SHITTY_UI__ = window.__SHITTY_UI__ || {};

  function ensureHost() {
    if (window.__SHITTY_UI__.host) return window.__SHITTY_UI__;

    const host = document.createElement("div");
    host.id = "shitty-ui-extension-root";
    host.setAttribute("data-shitty-ui", "true");
    Object.assign(host.style, {
      position: "fixed",
      inset: "0",
      pointerEvents: "none",
      zIndex: "2147483646",
    });

    const shadow = host.attachShadow({ mode: "closed" });
    const sheet = document.createElement("style");
    sheet.textContent = `
      :host { all: initial; }
      * { box-sizing: border-box; font-family: system-ui, Segoe UI, sans-serif; }
      .backdrop {
        pointer-events: auto;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.72);
        display: flex;
        align-items: center;
        justify-content: center;
        animation: fadeIn 0.2s ease;
      }
      @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-6px); }
        75% { transform: translateX(6px); }
      }
      .panel {
        pointer-events: auto;
        background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
        color: #e8e8e8;
        border-radius: 16px;
        padding: 24px;
        max-width: min(92vw, 420px);
        box-shadow: 0 24px 80px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.08);
      }
      .panel h2 {
        margin: 0 0 8px;
        font-size: 1.15rem;
        font-weight: 700;
        letter-spacing: -0.02em;
      }
      .panel p.sub {
        margin: 0 0 16px;
        font-size: 0.85rem;
        opacity: 0.75;
        line-height: 1.4;
      }
      .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
      button.btn {
        cursor: pointer;
        border: none;
        border-radius: 10px;
        padding: 10px 18px;
        font-size: 0.9rem;
        font-weight: 600;
      }
      button.btn-primary {
        background: linear-gradient(180deg, #7c3aed, #5b21b6);
        color: #fff;
      }
      button.btn-primary:hover { filter: brightness(1.08); }
      button.btn-ghost {
        background: rgba(255,255,255,0.08);
        color: #ccc;
      }
      button.btn-ghost:hover { background: rgba(255,255,255,0.14); }
      .error-msg {
        color: #f87171;
        font-size: 0.8rem;
        margin-top: 10px;
        min-height: 1.2em;
      }
    `;
    shadow.appendChild(sheet);

    const portal = document.createElement("div");
    portal.className = "shitty-portal";
    Object.assign(portal.style, { pointerEvents: "none" });
    shadow.appendChild(portal);

    document.documentElement.appendChild(host);

    window.__SHITTY_UI__.host = host;
    window.__SHITTY_UI__.shadow = shadow;
    window.__SHITTY_UI__.portal = portal;

    return window.__SHITTY_UI__;
  }

  window.__SHITTY_UI__.ensureHost = ensureHost;

  window.__SHITTY_UI__.showBackdrop = function (innerNode) {
    const { portal } = ensureHost();
    const backdrop = document.createElement("div");
    backdrop.className = "backdrop";
    backdrop.appendChild(innerNode);
    portal.appendChild(backdrop);
    portal.style.pointerEvents = "auto";
    setHostPointerBlock(true);

    function close() {
      backdrop.remove();
      if (!portal.children.length) {
        portal.style.pointerEvents = "none";
        setHostPointerBlock(false);
      }
    }

    return { backdrop, close };
  };

  function setHostPointerBlock(on) {
    const { host } = ensureHost();
    host.style.pointerEvents = on ? "auto" : "none";
  }
})();
