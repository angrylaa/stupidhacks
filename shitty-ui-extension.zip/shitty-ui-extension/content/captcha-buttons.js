(function () {
  "use strict";

  const U = window.__SHITTY_UI__;
  if (!U) return;

  const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const SKIP_ATTR = "data-shitty-captcha-pass";

  function randomChallenge() {
    let s = "";
    for (let i = 0; i < 5; i++) s += CHARS[Math.floor(Math.random() * CHARS.length)];
    return s;
  }

  function isButtonLike(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.closest("[data-shitty-ui]")) return false;
    const tag = el.tagName;
    if (tag === "BUTTON") return true;
    if (tag === "INPUT") {
      const t = (el.type || "").toLowerCase();
      return t === "submit" || t === "button" || t === "reset" || t === "image";
    }
    if (el.getAttribute("role") === "button") return true;
    if (tag === "A" && el.getAttribute("href")) {
      const h = el.getAttribute("href") || "";
      if (h === "#" || h.startsWith("javascript:")) return true;
    }
    return false;
  }

  function findClickable(start) {
    let el = start;
    for (let i = 0; i < 8 && el; i++) {
      if (isButtonLike(el)) return el;
      el = el.parentElement;
    }
    return null;
  }

  function openCaptchaModal(target, onSuccess) {
    U.ensureHost();
    const challenge = randomChallenge();

    const panel = document.createElement("div");
    panel.className = "panel";

    const h2 = document.createElement("h2");
    h2.textContent = "Prove you are human";
    const sub = document.createElement("p");
    sub.className = "sub";
    sub.textContent =
      "This button is protected. Type the characters below. They are definitely not readable on purpose.";

    const distort = document.createElement("div");
    Object.assign(distort.style, {
      fontSize: "1.75rem",
      fontWeight: "800",
      letterSpacing: "0.35em",
      textAlign: "center",
      padding: "16px",
      marginBottom: "12px",
      background: "repeating-linear-gradient(90deg, #333 0 2px, #222 2px 4px)",
      borderRadius: "12px",
      color: "#a78bfa",
      transform: "skewX(-8deg) rotate(-2deg)",
      textShadow: "3px 1px 0 #ec4899, -2px 2px 0 #22d3ee",
      userSelect: "none",
      fontFamily: "Georgia, serif",
    });
    distort.textContent = challenge.split("").join(" ");

    const input = document.createElement("input");
    input.type = "text";
    input.autocomplete = "off";
    input.placeholder = "Type the thing";
    Object.assign(input.style, {
      width: "100%",
      padding: "12px 14px",
      borderRadius: "10px",
      border: "1px solid rgba(255,255,255,0.2)",
      background: "rgba(0,0,0,0.35)",
      color: "#fff",
      fontSize: "1rem",
      marginBottom: "8px",
    });

    const err = document.createElement("div");
    err.className = "error-msg";

    const row = document.createElement("div");
    row.className = "row";

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "btn btn-ghost";
    cancel.textContent = "Give up";

    const go = document.createElement("button");
    go.type = "button";
    go.className = "btn btn-primary";
    go.textContent = "Unlock button";

    row.appendChild(cancel);
    row.appendChild(go);

    panel.appendChild(h2);
    panel.appendChild(sub);
    panel.appendChild(distort);
    panel.appendChild(input);
    panel.appendChild(err);
    panel.appendChild(row);

    const { close } = U.showBackdrop(panel);

    function fail(msg) {
      err.textContent = msg;
      panel.style.animation = "shake 0.35s ease";
      setTimeout(() => {
        panel.style.animation = "";
      }, 400);
    }

    cancel.addEventListener("click", () => close());
    go.addEventListener("click", () => {
      const v = input.value.trim().toUpperCase().replace(/\s/g, "");
      if (v === challenge) {
        close();
        onSuccess();
      } else {
        fail("Incorrect. Try squinting harder.");
      }
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") go.click();
    });

    setTimeout(() => input.focus(), 50);
  }

  document.addEventListener(
    "click",
    function (e) {
      const s = U.settings;
      if (!s || !s.captchaButtons) return;

      if (e.composedPath().some((n) => n instanceof Element && n.id === "shitty-ui-extension-root")) return;

      const t = e.target;
      if (t && t.closest && t.closest("[data-shitty-ui]")) return;

      const clickable = findClickable(t);
      if (!clickable) return;
      if (clickable.hasAttribute("disabled")) return;
      if (clickable.hasAttribute(SKIP_ATTR)) {
        clickable.removeAttribute(SKIP_ATTR);
        return;
      }

      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      openCaptchaModal(clickable, function () {
        clickable.setAttribute(SKIP_ATTR, "1");
        clickable.click();
      });
    },
    true
  );
})();
